package com.project.fat.service;

import com.project.fat.dto.UserDto;
import com.project.fat.entity.User;

public interface UserService {
	
	User addUser(UserDto user);
	User updateUSer();
	String deleteUser();

}
