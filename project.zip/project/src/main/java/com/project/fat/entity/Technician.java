package com.project.fat.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="technicianRegister")
public class Technician {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	//@Column(name="firstname")
	private String firstName;
	
	private String lastName;
	
	private String email;
		
	private long phone;
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	private String city;
	
	private String password;
	
	private Integer serviceId;

	/*
	 * private Services service;  //here service id should be given to the technician
	 * private String description; //Description about his experience on that particular service
	 * 
	 */
	
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstname() {
		return firstName;
	}

	public void setFirstname(String firstname) {
		this.firstName = firstname;
	}

	public String getSecondname() {
		return lastName;
	}

	public void setSecondname(String secondname) {
		this.lastName = secondname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	public long getMobilenumber() {
		return phone;
	}

	public void setMobilenumber(long mobilenumber) {
		this.phone = mobilenumber;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
	
	
	public Technician() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Technician(long id, String firstname, String secondname, String email, long aadharnumber,
			long mobilenumber, String city, String password) {
		super();
		this.id = id;
		this.firstName = firstname;
		this.lastName = secondname;
		this.email = email;
		this.phone = mobilenumber;
		this.city = city;
		this.password = password;
	}

	@Override
	public String toString() {
		return "TechRegisterEntity [id=" + id + ", firstname=" + firstName + ", secondname=" + lastName + ", email="
				+ email + ", aadharnumber="  + ", mobilenumber=" + phone + ", city=" + city
				+ ", password=" + password + "]";
	}

	public Integer getServiceId() {
		return serviceId;
	}

	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}
	
	

}
