 package com.project.fat.dto;

import com.project.fat.entity.User;


public class UserDto {
	
	private String firstname;
	private String lastname;
	private String city;
	private Long phoneNo;
	private String email;
	public UserDto(String firstname, String lastname, String city, Long phoneNo, String email) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.city = city;
		this.phoneNo = phoneNo;
		this.email = email;
	}
	
	public UserDto(User user) {
		super();
		this.firstname = user.getFirstname();
		this.lastname = user.getLastname();
		this.city = user.getCity();
		this.phoneNo = user.getPhoneNo();
		this.email = user.getEmail();
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	

}
