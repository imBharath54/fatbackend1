package com.project.fat.enums;

public enum Status {
	PENDING,ACCEPTED,ONGOING,COMPLETED,REJECTED


}
