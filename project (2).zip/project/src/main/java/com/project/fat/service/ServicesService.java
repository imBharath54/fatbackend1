package com.project.fat.service;

import com.project.fat.entity.Service;

public interface ServicesService {
	
	Service addService(Service service);
	void deleteService(Long id);
	Service editService(Service service);

}
