package com.project.fat.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.fat.dto.UserDto;
import com.project.fat.entity.User;
import com.project.fat.repository.UserRepository;
import com.project.fat.service.UserService;


@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public User addUser(UserDto user) {
		User userData = new User(user);
		User savedUser = userRepository.save(userData);
		
		
		return savedUser;
	}

	@Override
	public User updateUSer() {
		return null;
	}

	@Override
	public String deleteUser() {
		return null;
	}

}
