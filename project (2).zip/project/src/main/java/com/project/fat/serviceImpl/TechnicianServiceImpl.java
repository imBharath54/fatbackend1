package com.project.fat.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.fat.entity.Technician;
import com.project.fat.repository.TechnicianRepository;
import com.project.fat.service.TechnicianService;



@Service
public class TechnicianServiceImpl implements TechnicianService {
	
	@Autowired
	private TechnicianRepository techRepo;

	@Override
	public Technician saveTechnician(Technician techRegisterEntity) {
		return techRepo.save(techRegisterEntity);
	}

	@Override
	public Technician updateTechnician(Technician techRegisterEntity) {
		
		return techRepo.save(techRegisterEntity);
	}

//	@Override
//	public void deleteTechnician(TechRegisterEntity techRegisterEntity) {
//	       techRepo.delete(techRegisterEntity);
//		
//	}

	@Override
	public Technician findById(long id) {
		return techRepo.findById(id).get();
	}

	@Override
	public List<Technician> findAll() {
		return techRepo.findAll();
	}

	@Override
	public void deleteTechnician(long id) {
	       techRepo.deleteById(id);
		
	}
}
