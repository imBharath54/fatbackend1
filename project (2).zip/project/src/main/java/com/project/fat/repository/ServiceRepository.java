package com.project.fat.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.fat.entity.Service;

public interface ServiceRepository extends JpaRepository<Service, Long> {


}
