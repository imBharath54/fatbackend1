package com.project.fat.service;

import java.util.List;

import com.project.fat.entity.Technician;


public interface TechnicianService {
	
	public Technician saveTechnician(Technician techRegisterEntity);
	public Technician updateTechnician(Technician techRegisterEntity);
	//public void deleteTechnician(TechRegisterEntity techRegisterEntity);
	public void deleteTechnician(long id);
	public Technician findById(long id);
	public List<Technician> findAll();

	

}
