package com.project.fat.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.fat.entity.Technician;
import com.project.fat.service.TechnicianService;



@RestController
@CrossOrigin
@RequestMapping("/api/technician")
public class TechnicianController {
	
	@Autowired
	private TechnicianService technicianService;
	
	@PostMapping("/register")
    public ResponseEntity<Technician> createTechnician(@RequestBody Technician technician) {
        Technician createdTechnician = technicianService.saveTechnician(technician);
        return new ResponseEntity<>(createdTechnician, HttpStatus.CREATED);
    }
	
	
	@GetMapping("/all")
	public List<Technician> findAllTechnicians()
	{
		List<Technician> technicians=technicianService.findAll();
		return technicians;
	}
    
	 @GetMapping("/{id}")
	 public ResponseEntity<?> getTechnicianById(@PathVariable("id") long id) {
	  try {
	       Technician technician = technicianService.findById(id);
	        if (technician != null) {
	                return new ResponseEntity<>(technician, HttpStatus.OK);
	            } else {
	                return new ResponseEntity<>("Technician not found", HttpStatus.NOT_FOUND);
	            }
	        } catch (Exception e) {
	            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    }
	 
	 @DeleteMapping("/{id}")
	    public ResponseEntity<?> deleteTechnician(@PathVariable("id") long id) {
	        try {
	            technicianService.deleteTechnician(id);
	            return new ResponseEntity<>("Technician deleted successfully", HttpStatus.OK);
	        } catch (Exception e) {
	            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    }
	 

	
}
