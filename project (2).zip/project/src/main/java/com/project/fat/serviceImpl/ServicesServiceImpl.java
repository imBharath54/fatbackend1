package com.project.fat.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;

import com.project.fat.entity.Service;
import com.project.fat.repository.ServiceRepository;
import com.project.fat.service.ServicesService;

public class ServicesServiceImpl implements ServicesService {
	
	@Autowired
	private ServiceRepository serviceRepository;

	@Override
	public Service addService(Service service) {
		Service saved = serviceRepository.save(service);
		return saved;
	}

	@Override
	public void deleteService(Long id) {
		
		serviceRepository.deleteById(id);
		
	}

	@Override
	public Service editService(Service service) {
		
		Service previous = serviceRepository.getById(service.getId());
		previous.setName(service.getName());
		previous.setDescription(service.getDescription());
		previous.setPrice(service.getPrice());
		
		return serviceRepository.save(previous);
		
	}

}
