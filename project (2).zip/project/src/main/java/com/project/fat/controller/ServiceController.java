package com.project.fat.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.fat.entity.Service;
import com.project.fat.repository.ServiceRepository;
import com.project.fat.service.ServicesService;

@RestController
public class ServiceController {
	@Autowired
	ServicesService servicesService;
	
	@PostMapping
	public ResponseEntity<?> addService(@RequestBody Service service){
		Service saved = servicesService.addService(service);
		return ResponseEntity.ok(saved);
		
	}
	

}
