package com.project.fat.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.fat.entity.Technician;

public interface TechnicianRepository extends JpaRepository<Technician, Long> {

}
